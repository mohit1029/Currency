insert into exchange_value(id,currency_from,currency_to,conversion_mutliple,port)
values(10001,'USD','INR',72,0);
insert into exchange_value(id,currency_from,currency_to,conversion_mutliple,port)
values(10002,'EUR','INR',85,0);
insert into exchange_value(id,currency_from,currency_to,conversion_mutliple,port)
values(10003,'AUD','INR',52,0);