package com.learnspringcloud.currencyconversionservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CurrencyConversionServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
